function bodyloaded()
{
	new Webvisu('background', 'foreground', false, false);
	let factor=(window.innerHeight/750);
	$('body').css('transform-origin','left top 0px');
	$('body').css('transform','scale('+factor+')');
    /*if(0) {
            var step =17;
            currIEZoom += step;
            $('body').css('zoom', ' ' + currIEZoom + '%');
        }*/

}
